"""Cliente HTTP seguro: limita tempo e tamanho, não segue redirecionamentos automáticos e revalida cada destino."""
import httpx

from app.security.url_guard import check_url, resolves_to_public_ip


class UnsafeURL(Exception):
    pass


async def safe_get(url: str, *, timeout: float, max_bytes: int, headers: dict | None = None,
                   max_redirects: int = 3) -> bytes:
    current = url
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, headers=headers or {}) as client:
        for _ in range(max_redirects + 1):
            ok, why = check_url(current)
            if not ok:
                raise UnsafeURL(why)
            host = httpx.URL(current).host
            if not resolves_to_public_ip(host):
                raise UnsafeURL("host resolve para IP não público")
            async with client.stream("GET", current) as resp:
                if resp.is_redirect:
                    current = str(resp.url.join(resp.headers.get("location", "")))
                    continue
                resp.raise_for_status()
                chunks, total = [], 0
                async for chunk in resp.aiter_bytes():
                    total += len(chunk)
                    if total > max_bytes:
                        raise UnsafeURL("resposta grande demais")
                    chunks.append(chunk)
                return b"".join(chunks)
    raise UnsafeURL("redirecionamentos demais")
